package com.example.CricScores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class open2 extends AppCompatActivity {
    Button btnscore, btnstats, btnranks,btnnews;
    //this page contains the intent objects to all the different pages
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open2);
        btnscore = (Button) findViewById(R.id.b1);
        btnscore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(open2.this, ScoresPage.class);
                startActivity(i);//this intent activity is for scores page
            }
        });

        btnstats = (Button) findViewById(R.id.b2);
        btnstats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(open2.this, statistics.class);
                startActivity(i);
                Toast.makeText(getBaseContext(), "WELCOME TO STATS  WORLD", Toast.LENGTH_LONG).show();
            }//this intent activity  is for statistics
        });

        btnranks = (Button) findViewById(R.id.b3);
        btnranks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(open2.this, Testranking.class);
                startActivity(i);
                Toast.makeText(getBaseContext(), "!!LATEST TEAM RANKINGS!!", Toast.LENGTH_LONG).show();
            }//this intent is for rankings page
        });
        btnnews = (Button) findViewById(R.id.b4);
        btnnews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(open2.this, news.class);
                startActivity(i);
                Toast.makeText(getBaseContext(), "!!LATEST NEWS!!", Toast.LENGTH_LONG).show();
            }//the last intent activity for news page
        });
    }
}